package FlightPackage;

import java.io.*;
import java.sql.*;
import java.util.*;
import com.google.gson.Gson;
import javax.servlet.http.HttpSession;

public class Booking {
	Connection con;
	
	public Booking(){
		DatabaseConn dbCon = new DatabaseConn();
		con = dbCon.getConnection();
	}

	public Boolean bookFlight(int user_id, int flight_id,String seat_type,int seats,int fare_with_miles,int fare_without_miles,int miles_used,int miles_remaining, int miles_earned, String payment_choice){
		
		Statement stmt = null;
		String query_start_trans = "START TRANSACTION";
		String query_start_commit = "COMMIT";
		String query_start_rollback = "ROLLBACK";
		Boolean retval = false;

		try{
			stmt = con.createStatement();
			//start transaction
			ResultSet queryRes = stmt.executeQuery(query_start_trans);

			//check if seats still available
			if(checkAvailability(flight_id,seat_type,seats)){
				//make the payment
				if(makePayment(user_id, flight_id,seat_type,seats,fare_with_miles,fare_without_miles,miles_used,miles_remaining, miles_earned, payment_choice)){
					retval = true;
				}else{
					throw new Exception();
				}
			}else{
				throw new Exception();
			}

			//commit
		}catch(Exception e){
			retval = false;
		}

		try{
			if(retval){
				ResultSet queryRes = stmt.executeQuery(query_start_commit);
			}else{
				ResultSet queryRes = stmt.executeQuery(query_start_rollback);
			}			
		}catch(Exception e){
			System.out.println(e);
		}
		return retval;
	}

	public void refreshMiles(HttpSession session){
		try{
			int user_id = Integer.parseInt(session.getAttribute("user_id").toString());

			Statement stmt = con.createStatement();
			//start transaction
			ResultSet queryRes = stmt.executeQuery("SELECT * FROM flt_users WHERE user_id = "+user_id+";");

			queryRes.next();

			int air_miles = queryRes.getInt("air_miles");

			session.setAttribute("air_miles",air_miles);			
		}catch(Exception e){
			System.out.println(e);
		}
	}

	public Boolean cancelBooking(int booking_id){

		Statement stmt = null;
		String query_start_trans = "START TRANSACTION";
		String query_start_commit = "COMMIT";
		String query_start_rollback = "ROLLBACK";
		Boolean retval = false;

		try{
			stmt = con.createStatement();
			//start transaction
			ResultSet queryRes = stmt.executeQuery(query_start_trans);

			// get booking details
			String query = "select * from flt_booking,flt_flight,flt_route where flt_booking.flight_id = flt_flight.flight_id AND flt_flight.route_id = flt_route.route_id AND flt_booking.booking_id="+booking_id+";";
			queryRes = stmt.executeQuery(query);
			System.out.println(query);

			int user_id;
			int flight_id;
			String seat_type;
			int seats;
			int miles_used;
			int total_amount;
			int route_miles;

			queryRes.next();
			user_id = queryRes.getInt("user_id");
			flight_id = queryRes.getInt("flight_id");
			seat_type = queryRes.getString("class");
			seats = queryRes.getInt("seats");
			miles_used = queryRes.getInt("miles_used");
			total_amount = queryRes.getInt("total_amount");
			route_miles = queryRes.getInt("miles");

			// add back seats
			query = "UPDATE flt_flight SET vacancy_"+seat_type+"=vacancy_"+seat_type+" + "+seats+" WHERE  flight_id="+flight_id+";";
			int queryResInt = stmt.executeUpdate(query);
			System.out.println(query);

			// reclaim added miles
			query = "UPDATE flt_users SET air_miles= air_miles - '"+route_miles+"' WHERE  user_id="+user_id+";";
			queryResInt = stmt.executeUpdate(query);
			System.out.println(query);

			// remove booking entry
			query = "DELETE FROM flt_booking WHERE booking_id="+booking_id+";";
			queryResInt = stmt.executeUpdate(query);			
			System.out.println(query);
			
			retval = true;
			//commit
		}catch(Exception e){
			retval = false;
			System.out.println(e);
		}

		try{
			if(retval){
				ResultSet queryRes = stmt.executeQuery(query_start_commit);
			}else{
				ResultSet queryRes = stmt.executeQuery(query_start_rollback);
			}			
		}catch(Exception e){
			System.out.println(e);
		}
		return retval;
	}

	public Boolean makePayment(int user_id, int flight_id,String seat_type,int seats,int fare_with_miles,int fare_without_miles,int miles_used,int miles_remaining, int miles_earned, String payment_choice){

		try{
			Statement stmt = con.createStatement();
			
			//reduce seat count
			String query = "UPDATE flt_flight SET vacancy_"+seat_type+"=vacancy_"+seat_type+" -"+seats+" WHERE  flight_id="+flight_id+";";
			int queryRes = stmt.executeUpdate(query);
			
			//add entry to booking table
			if(payment_choice.equals("with_miles")){
				query = "INSERT INTO flt_booking (user_id, flight_id, class, seats, miles_used, total_amount) VALUES ('"+user_id+"', '"+flight_id+"', '"+seat_type+"', '"+seats+"', '"+miles_used+"', '"+fare_with_miles+"');";
			}else{
				query = "INSERT INTO flt_booking (user_id, flight_id, class, seats, miles_used, total_amount) VALUES ('"+user_id+"', '"+flight_id+"', '"+seat_type+"', '"+seats+"', '0', '"+fare_without_miles+"');";
			}
			queryRes = stmt.executeUpdate(query);

			//deduct chosen miles from user's account
			query = "UPDATE flt_users SET air_miles='"+miles_remaining+"' WHERE  user_id="+user_id+";";
			queryRes = stmt.executeUpdate(query);
			
			//add current miles to user's account
			query = "UPDATE flt_users SET air_miles= air_miles + '"+miles_earned+"' WHERE  user_id="+user_id+";";
			queryRes = stmt.executeUpdate(query);			
		}catch(Exception e){
			System.out.println(e);
			return false;
		}
		
		return true;
		
	}

	public Boolean checkAvailability(int flight_id, String seat_type, int seats){
		Boolean op = null;
		try{
			String query = "select  count(*) as flight_available from flt_flight where flight_id="+flight_id+" and vacancy_"+seat_type+" >= "+seats+";";

			Statement stmt = null;
			ResultSet queryRes = null;

			stmt = con.createStatement();
			queryRes = stmt.executeQuery(query);

			int flight_available = -1;

			queryRes.next();
			
			flight_available = queryRes.getInt("flight_available");

			if(flight_available == 1){
				op = true;
			}else{
				op = false;
			}
		}catch(Exception e){
			System.out.println(e);
			op = false;
		}
		return op;		
	}

	public int[] getFare(int flight_id, String seat_type, int seats, int user_miles){
		int op[] = new int[4];
		
		op[0] = calculateFare_withMiles(flight_id,seat_type,seats,user_miles);
		op[1] = calculateFare_withoutMiles(flight_id,seat_type,seats);
		// miles used
		int miles_remaining = user_miles - (op[1] * 2);
		if(miles_remaining < 0){
			miles_remaining = 0;
		}
		op[2] = miles_remaining;
		op[3] = getMilesEarned(flight_id);

		return op;
	}

	public int getMilesEarned(int flight_id){
		int miles_earned = 0;
		try{
			String query = "select * from flt_flight as t1,flt_route as t2 where t1.route_id = t2.route_id AND flight_id="+flight_id+";";

			Statement stmt = null;
			ResultSet queryRes = null;

			stmt = con.createStatement();
			queryRes = stmt.executeQuery(query);

			queryRes.next();
			miles_earned = queryRes.getInt("miles");
		}catch(Exception e){
			System.out.println(e);
		}

		return miles_earned;
	}

	public int calculateFare_withMiles(int flight_id, String seat_type, int seats, int user_miles){

		int total_price_without_miles = calculateFare_withoutMiles(flight_id, seat_type, seats);

		// int miles = 0;
		int miles_discount = (int)(user_miles * 0.5);
		int final_fare = total_price_without_miles - miles_discount;
		if(final_fare < 0){
			return 0;
		}else{
			return final_fare;
		}
	}

	public int calculateFare_withoutMiles(int flight_id, String seat_type, int seats){
		int total_price = 0;
		try{
			String query = "select * from flt_flight as t1,flt_route as t2 where t1.route_id = t2.route_id AND flight_id="+flight_id+";";

			Statement stmt = null;
			ResultSet queryRes = null;

			stmt = con.createStatement();
			queryRes = stmt.executeQuery(query);

			// int miles = 0;
			int miles_discount = 0;

			int seat_price = 0;

			queryRes.next();
			seat_price = queryRes.getInt("price_"+seat_type);

			total_price = seat_price * seats;			
		}catch(Exception e){
			System.out.println(e);
		}
		
		return total_price;
				
	}

}